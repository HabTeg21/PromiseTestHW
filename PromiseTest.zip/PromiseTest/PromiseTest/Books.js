﻿fetch("https://fakerestapi.azurewebsites.net/api/Book").then(
    res => {
        res.json().then(
            data => {
                console.log(data);
                if (data.length > 0) {
                    var row = "";

                    data.forEach((u) => {
                        row += "<tr>";
                        row += "<td>" + u.id + "</td>";
                        row += "<td>" + u.book + "</td>";
                        row += "<td>" + u.author + "</td> </tr>";
                    })
                    document.querySelector("#bookTable").innerHTML = row;
                }
            }
        )
    }
)