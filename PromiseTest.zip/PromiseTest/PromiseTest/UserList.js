﻿fetch("https://fakerestapi.azurewebsites.net/api/Users").then(
    res => {
        res.json().then(
            data => {
                console.log(data);
                if (data.length > 0) {
                    var row = "";

                    data.forEach((u) => {
                        row += "<tr>";
                        row += "<td>" + u.name + "</td>";
                        row += "<td>" + u.age + "</td>";
                        row += "<td>" + u.email + "</td> </tr>";
                    })
                    document.querySelector("#usersTable").innerHTML = row;
                }
            }
        )
    }
)
