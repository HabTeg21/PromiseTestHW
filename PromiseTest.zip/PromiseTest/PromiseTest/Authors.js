﻿fetch("https://fakerestapi.azurewebsites.net/api/Author").then(
    res => {
        res.json().then(
            data => {
                console.log(data);
                if (data.length > 0) {
                    var row = "";

                    data.forEach((u) => {
                        row += "<tr>";
                        row += "<td>" + u.id + "</td>";
                        row += "<td>" + u.firstName + "</td>";
                        row += "<td>" + u.lastName + "</td> </tr>";
                    })
                    document.querySelector("#authorTable").innerHTML = row;
                }
            }
        )
    }
)